#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
中山街道公共法律服务数据 - 基于Excel表格
"""
import asyncio
import asyncpg
import os

# Excel表格中的24个居委会及详细信息
EXCEL_DATA = [
    {"name": "莱顿", "station_name": "莱顿公共法律服务工作（站）室", "phone": "57786538", "address": "莱顿小城46号楼底楼", "lawyer": "吴周杰", "lawyer_phone": "13681836930", "hours": "每月20日（上午9：00-11：00，下午13：00-17：00）"},
    {"name": "淡家浜", "station_name": "淡家浜公共法律服务工作（站）室", "phone": "67890573", "address": "淡家浜街88弄19号底楼", "lawyer": "金慧霞", "lawyer_phone": "13482726216", "hours": "每月20日（上午9：00-11：00，下午13：00-17：00）"},
    {"name": "黄渡浜", "station_name": "黄渡浜公共法律服务工作（站）室", "phone": "67670278", "address": "光星路1686号南侧", "lawyer": "金慧霞", "lawyer_phone": "13482726216", "hours": "每月10日（上午9：00-11：00，下午13：00-17：00）"},
    {"name": "中山苑", "station_name": "中山苑公共法律服务工作（站）室", "phone": "57783791", "address": "茸惠路758弄34号二楼", "lawyer": "张艳丽", "lawyer_phone": "13564820463", "hours": "每月第3个周二（上午9：00-11：00，下午13：00-17：00）"},
    {"name": "花桥", "station_name": "花桥公共法律服务工作（站）室", "phone": "37790512", "address": "茸惠路1100弄37号二楼", "lawyer": "张艳丽", "lawyer_phone": "13564820463", "hours": "每月15日（上午9：00-11：00，下午13：00-17：00）"},
    {"name": "郭家娄", "station_name": "郭家娄公共法律服务工作（站）室", "phone": "37789088", "address": "长水街217号底楼", "lawyer": "吴周杰", "lawyer_phone": "13681836930", "hours": "每月10日（上午9：00-11：00，下午13：00-17：00）"},
    {"name": "茸树", "station_name": "茸树公共法律服务工作（站）室", "phone": "57780108", "address": "茸树路600弄9号底楼", "lawyer": "张双超", "lawyer_phone": "13621971552", "hours": "每月第1个周一（上午9：00-11：00，下午13：00-17：00）"},
    {"name": "茸梅", "station_name": "茸梅公共法律服务工作（站）室", "phone": "57782674", "address": "茸梅路200号天虹四村194号", "lawyer": "张婷", "lawyer_phone": "15202122794", "hours": "每月30号（2月最后一天）（上午9：00-11：00，下午13：00-17：00）"},
    {"name": "茸星", "station_name": "茸星公共法律服务工作（站）室", "phone": "37820387", "address": "沪松路255弄16号", "lawyer": "姚莉", "lawyer_phone": "13681967342", "hours": "每月第二周周一（上午9:00-下午15:00）"},
    {"name": "五龙", "station_name": "五龙公共法律服务工作（站）室", "phone": "57780312", "address": "松江区茸平路288弄48号二楼", "lawyer": "姚莉", "lawyer_phone": "13681967342", "hours": "每月第一周周五（上午9:00-下午15:00）"},
    {"name": "北门", "station_name": "北门公共法律服务工作（站）室", "phone": "57838362", "address": "沪松路5弄20号", "lawyer": "张金标", "lawyer_phone": "18817562422", "hours": "每月第二周周五（上午9:00-11:00，下午13:00-17:00）"},
    {"name": "方西", "station_name": "方西公共法律服务工作（站）室", "phone": "57834965", "address": "中山东路165弄25号101室", "lawyer": "张金标", "lawyer_phone": "18817562422", "hours": "每月20号（上午9:00-11:00，下午13:00-17:00）"},
    {"name": "蓝天一村", "station_name": "蓝天一村公共法律服务工作（站）室", "phone": "57741308", "address": "松东路195-1号", "lawyer": "张婷", "lawyer_phone": "15202122794", "hours": "每月15号（上午9:00-下午15:00）"},
    {"name": "蓝天二村", "station_name": "蓝天二村公共法律服务工作（站）室", "phone": "57744029", "address": "松东路193弄蓝天新村338号", "lawyer": "王萌", "lawyer_phone": "18201987609", "hours": "每月第二周（周三上午8：30-11：00），第四周（周三下午13：00-16：30）"},
    {"name": "蓝天四村", "station_name": "蓝天四村公共法律服务工作（站）室", "phone": "57745767", "address": "上海市松江区苗盛路33弄1号103室", "lawyer": "俞长生", "lawyer_phone": "13916014120", "hours": "每月15日（上午9:00-11:00，下午13:00-17:00）"},
    {"name": "蓝天五村", "station_name": "蓝天五村公共法律服务工作（站）室", "phone": "57746187", "address": "荣乐东路1763弄28号", "lawyer": "张梅", "lawyer_phone": "13482002182", "hours": "每月第二周（周四上午8：30-11：00），第四周（周四下午13：00-16：30）"},
    {"name": "同济雅筑", "station_name": "同济雅筑公共法律服务工作（站）室", "phone": "67671027", "address": "环城路886弄31号", "lawyer": "何斯斯", "lawyer_phone": "18501626394", "hours": "每月第一周周五（上午9:00-下午15:00）"},
    {"name": "平桥", "station_name": "平桥公共法律服务工作（站）室", "phone": "57830005", "address": "中山东路70弄1号楼底楼", "lawyer": "张金标", "lawyer_phone": "18817562422", "hours": "每月10号（上午9：00-11：00，下午13：00-17：00）"},
    {"name": "东外", "station_name": "东外公共法律服务工作（站）室", "phone": "57830405", "address": "环城路环城新村78号", "lawyer": "庄子艺", "lawyer_phone": "13817100098", "hours": "每月第二周周二（上午8:30-下午14:30）"},
    {"name": "方东", "station_name": "方东公共法律服务工作（站）室", "phone": "57834858", "address": "迎宾路2号", "lawyer": "张梅", "lawyer_phone": "13482002182", "hours": "每月第二周（周四下午13：00-16：30），第四周（周四上午8：30-11：00）"},
    {"name": "白云", "station_name": "白云公共法律服务工作（站）室", "phone": "57834350", "address": "白云新村5号", "lawyer": "周丹", "lawyer_phone": "13621947192", "hours": "每月7日（上午8:30-下午14:30）"},
    {"name": "南门", "station_name": "南门公共法律服务工作（站）室", "phone": "67715101", "address": "松汇东路149弄16号", "lawyer": "庄子艺", "lawyer_phone": "13817100098", "hours": "每月第二周周四（上午8:30-下午14:30）"},
    {"name": "茸虹", "station_name": "茸虹公共法律服务工作（站）室", "phone": "57783618", "address": "五昆路88弄16号1层", "lawyer": "姚莉", "lawyer_phone": "13681967342", "hours": "每月第三周周五（上午9:00-下午15:00）"},
    {"name": "茸吉", "station_name": "茸吉公共法律服务工作（站）室", "phone": "57783936", "address": "茸盛路99弄122号", "lawyer": "张双超", "lawyer_phone": "13621971552", "hours": "每月14日（周末顺延）（上午9：00-11：00，下午13：00-17：00）"},
]

async def seed_data():
    # Connect to database
    conn = await asyncpg.connect(
        user='sillymd',
        password='sillymd123',
        host='localhost',
        port=5432,
        database='sillymd'
    )

    print("Connected to database")

    # Check existing data
    existing = await conn.fetch("SELECT name FROM config_data WHERE category = 'public_law_service'")
    existing_names = [row['name'] for row in existing]
    print(f"Existing items: {len(existing_names)}")

    # Insert missing items
    inserted = 0
    for item in EXCEL_DATA:
        if item['name'] not in existing_names:
            await conn.execute('''
                INSERT INTO config_data (category, name, data, position_x, position_y)
                VALUES ($1, $2, $3, $4, $5)
            ''',
                'public_law_service',
                item['name'],
                {
                    'station_name': item['station_name'],
                    'phone': item['phone'],
                    'address': item['address'],
                    'lawyer': item['lawyer'],
                    'lawyer_phone': item['lawyer_phone'],
                    'hours': item['hours']
                },
                50.0,  # Default position_x
                50.0   # Default position_y
            )
            print(f"  Inserted: {item['name']}")
            inserted += 1
        else:
            print(f"  Already exists: {item['name']}")

    print(f"\nInserted {inserted} new items")

    # Verify final count
    final = await conn.fetch("SELECT COUNT(*) FROM config_data WHERE category = 'public_law_service'")
    print(f"Total items now: {final[0]['count']}")

    await conn.close()
    print("Done!")

if __name__ == "__main__":
    asyncio.run(seed_data())
